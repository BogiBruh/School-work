package com.mygdx.game.paint;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;
import com.badlogic.gdx.graphics.glutils.ShaderProgram;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.Null;

public class WriteableImage {
    public FrameBuffer mainBuffer;
    public FrameBuffer helperBuffer;
    public int w, h;
    public SpriteBatch batch;
    public ShapeRenderer renderer;
    public static ShaderProgram invertShader;

    public static void init(){
        ShaderProgram.pedantic = false;
        String invert = Gdx.files.internal("invert.fsh").readString();
        String vertex = Gdx.files.internal("vertex.vsh").readString();

        invertShader = new ShaderProgram(vertex, invert);
    }

    public WriteableImage(int w, int h){
        this.w = w;
        this.h = h;
        batch = new SpriteBatch();
        renderer = new ShapeRenderer();

        mainBuffer = new FrameBuffer(Pixmap.Format.RGBA8888 , w, h, false);
        helperBuffer = new FrameBuffer(Pixmap.Format.RGBA8888 , w, h, false);
    }

    public void draw(int x, int y){
        Texture t = mainBuffer.getColorBufferTexture();

        batch.begin();

        batch.draw(t, x, y);

        batch.end();
    }

    public void drawCircle(int x, int y, int r, Color color){
        mainBuffer.begin();
        renderer.begin(ShapeRenderer.ShapeType.Filled);
        renderer.setColor(color);
        renderer.circle(x, y, r);
        renderer.end();
        mainBuffer.end();
    }

    public void drawLine(int x, int y, int px, int py, Color color){
        mainBuffer.begin();
        renderer.begin(ShapeRenderer.ShapeType.Filled);
        renderer.setColor(color);
        renderer.rectLine(x, y, px, py, 3);
        renderer.end();
        mainBuffer.end();
    }

    public void invert(){
        Texture t = mainBuffer.getColorBufferTexture();

        helperBuffer.begin();
        batch.begin();
        batch.setShader(invertShader);

        batch.draw(t, 0, 0);

        batch.setShader(null);
        batch.end();
        helperBuffer.end();

        FrameBuffer f = mainBuffer;
        mainBuffer = helperBuffer;
        helperBuffer = f;
    }
}
