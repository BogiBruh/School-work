package com.mygdx.game.paint;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.ScreenUtils;

public class Main extends ApplicationAdapter {
    public WriteableImage img;
    public static int w, h;
    public int px, py;

    @Override
    public void create() {
        WriteableImage.init();

        w = Gdx.graphics.getWidth();
        h = Gdx.graphics.getHeight();
        img = new WriteableImage(w, h);
        px = 0;
        py = 0;
    }

    @Override
    public void render() {
        ScreenUtils.clear(1,1,1,1);
        img.draw(0, 0);
        int x = Gdx.input.getX();
        int y = Gdx.input.getY();

        if(Gdx.input.isButtonPressed(Input.Buttons.LEFT)){


            //img.drawCircle(x, y, 20, Color.BLACK);
            img.drawLine(x, y, px, py, Color.RED);

        }

        if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE)){
            img.invert();

        }
        px = x;
        py = y;
    }

    @Override
    public void dispose() {

    }
}
