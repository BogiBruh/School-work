package com.mygdx.game.scene2DIntro;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class Main extends ApplicationAdapter {
    public Stage stage;
    public int w, h;
    public Table table;
    public TextButton buton;

    @Override
    public void create() {
        w = Gdx.graphics.getWidth();
        h = Gdx.graphics.getHeight();

        stage = new Stage(new FitViewport(w, h));
       //Gdx.input
        table = new Table();
        stage.addActor(table);
        table.setFillParent(true);

        BitmapFont font = new BitmapFont();
        TextButton.TextButtonStyle style = new TextButton.TextButtonStyle(null, null, null, font);

        for(int i = 0; i < 2; i++){
            for(int j = 0; j < 4; j++){
                buton = new TextButton("Hello", style);
                buton.pad(20);
//                buton.addListener(new ClickListener()){
//
//                }
                table.add(buton);
            }
            table.row();
        }

    }

    @Override
    public void render() {
        ScreenUtils.clear(1,1,1,1);
        stage.draw();
    }
}
