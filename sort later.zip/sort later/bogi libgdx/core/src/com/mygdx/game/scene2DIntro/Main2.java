package com.mygdx.game.scene2DIntro;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class Main2 extends ApplicationAdapter {
    Stage stage;

    @Override
    public void create() {
        int w = Gdx.graphics.getWidth();
        int h = Gdx.graphics.getHeight();
      stage = new Stage(new FitViewport(w, h));

      Gdx.input.setInputProcessor(stage);

        Table table = new Table();
        stage.addActor(table);
        table.setFillParent(true);
        CustomButton.init();
        CustomButton btn = new CustomButton("test");

        table.add(btn);
    }

    @Override
    public void render() {
        ScreenUtils.clear(1,1,1,1);
        stage.draw();
    }
}
