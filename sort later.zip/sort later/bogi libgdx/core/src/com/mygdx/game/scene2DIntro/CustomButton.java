package com.mygdx.game.scene2DIntro;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;

public class CustomButton extends TextButton {
    public static TextButtonStyle style;
    public static ShapeRenderer renderer;

    public static void init(){
        BitmapFont font = new BitmapFont();
        style = new TextButtonStyle(null, null, null, font);
        renderer = new ShapeRenderer();
    }

    public CustomButton(String text){
        super(text,style);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.end();

        float x = getX();
        float y = getY();
        float w = getWidth();
        float h = getHeight();

        renderer.begin();
        renderer.setColor(Color.RED);
        renderer.rect(x,y,w,h);
        renderer.end();

        batch.begin();
    }
}
