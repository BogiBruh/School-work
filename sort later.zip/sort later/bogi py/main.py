brojac = 0
string = "evo ga test string broj slova o je 4"
for i in range(len(string)):
    if string[i] == 'o':
        brojac = brojac + 1
print("broj slova je " + str(brojac))