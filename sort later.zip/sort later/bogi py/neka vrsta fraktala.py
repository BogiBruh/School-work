import turtle as point
import math
sc = point.Screen

def sq(i, n):
    sirina = 1
    x = 0
    y = 0
    for j in range(n):
        k = i % 4
        if k == 1:
            y += sirina
        if k == 2:
            x += sirina
            y += sirina
        if k == 3:
            x += sirina
        i = i / 4
        sirina = sirina * 2 + 1
    return (x, y)

a = 20
n = 2

for i in range(2 << (n+1)):
    tacka = sq(i, n)
    point.setpos(tacka[0] * a, tacka[1] * a)

input()