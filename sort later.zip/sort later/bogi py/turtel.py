import turtle
import time
sc = turtle.Screen()

def loadCode(vremenskiPeriod):
    for i in range(vremenskiPeriod):
        turtle.left(133)
        turtle.forward(250)

turtle.speed(0.2)
for i in range(999):
    loadCode(2)
    sc.title("loading function serverHck()")
    loadCode(4)
    time.sleep(1)
    sc.title("loading function serverHck().")
    loadCode(3)
    time.sleep(1)
    sc.title("loading function serverHck()..")
    loadCode(7)
    time.sleep(1)
    sc.title("loading function serverHck()...")
    loadCode(4)
    time.sleep(1)
 #   turtle.

