import random

def listToString(s): 
    
    # initialize an empty string
    str1 = " " 
    
    # return string  
    return (str1.join(s))

karakteri = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '!', '@', '_', '-', '/', '#']
lozina = ""
najmanji_broj = random.randint(1, 255)
najveci_broj = random.randint(1, 255)
if(najmanji_broj > najveci_broj):
    veci = najmanji_broj
    manji = najveci_broj
else: 
    veci = najveci_broj
    manji = najmanji_broj
minimal = random.randint(manji, veci)
maximal = random.randint(random.randint(7,19285), random.randint(1, 69123745))
seed = random.randint(minimal, maximal)

random.seed(seed)

for i in range(13):
    random.shuffle(karakteri)
    random.shuffle(karakteri)
    random.shuffle(karakteri)
    lozina = lozina + listToString(random.choices(karakteri, k = 1))
    random.shuffle(karakteri)
    random.shuffle(karakteri)
    random.shuffle(karakteri)

print(lozina)